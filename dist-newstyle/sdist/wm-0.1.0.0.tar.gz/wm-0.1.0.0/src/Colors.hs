module Colors (module Colors.DoomOne) where

import Colors.DoomOne
